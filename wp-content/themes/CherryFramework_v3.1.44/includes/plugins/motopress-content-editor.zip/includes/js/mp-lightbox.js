jQuery(document).ready(function(a){jQuery('[rel="motopressLightbox"]').magnificPopup({type:"image",closeOnContentClick:!0,mainClass:"mfp-img-mobile",image:{verticalFit:!0}})});
